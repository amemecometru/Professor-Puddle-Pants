import { useEffect, useRef, useState } from 'react'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { 
  Code, Palette, Database, Shield, FileText, 
  Layers, Sparkles, ArrowRight, Check,
  Menu, X, Cpu, Terminal, Box
} from 'lucide-react'
import './App.css'

gsap.registerPlugin(ScrollTrigger)

function App() {
  const [email, setEmail] = useState('')
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  
  // Refs for sections
  const heroRef = useRef<HTMLDivElement>(null)
  const whatYouGetRef = useRef<HTMLDivElement>(null)
  const stackRef = useRef<HTMLDivElement>(null)
  const netRef = useRef<HTMLDivElement>(null)
  const workflowRef = useRef<HTMLDivElement>(null)
  const freshPicksRef = useRef<HTMLDivElement>(null)
  const newArrivalsRef = useRef<HTMLDivElement>(null)
  const trendingRef = useRef<HTMLDivElement>(null)
  const ctaRef = useRef<HTMLDivElement>(null)

  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (email) {
      setIsSubmitted(true)
      setTimeout(() => setIsSubmitted(false), 3000)
      setEmail('')
    }
  }

  useEffect(() => {
    // Hero entrance animation (auto-play on load)
    const heroTl = gsap.timeline({ delay: 0.2 })
    
    heroTl
      .fromTo('.hero-image', 
        { opacity: 0, x: '-12vw', scale: 0.96 },
        { opacity: 1, x: 0, scale: 1, duration: 1, ease: 'power3.out' }
      )
      .fromTo('.hero-card',
        { opacity: 0, x: '12vw', scale: 0.98 },
        { opacity: 1, x: 0, scale: 1, duration: 1, ease: 'power3.out' },
        '-=0.9'
      )
      .fromTo('.hero-headline span',
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.03, ease: 'power2.out' },
        '-=0.5'
      )
      .fromTo('.hero-subtext',
        { y: 16, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
        '-=0.3'
      )
      .fromTo('.hero-form',
        { y: 16, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.5, ease: 'power2.out' },
        '-=0.3'
      )

    // Hero scroll-driven exit animation
    const heroScrollTl = gsap.timeline({
      scrollTrigger: {
        trigger: heroRef.current,
        start: 'top top',
        end: '+=130%',
        pin: true,
        scrub: 0.6,
        onLeaveBack: () => {
          // Reset hero elements when scrolling back to top
          gsap.set('.hero-image', { opacity: 1, x: 0, scale: 1 })
          gsap.set('.hero-card', { opacity: 1, x: 0, scale: 1 })
          gsap.set('.hero-headline', { opacity: 1, y: 0 })
        }
      }
    })

    heroScrollTl
      .fromTo('.hero-image',
        { x: 0, opacity: 1 },
        { x: '-55vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      )
      .fromTo('.hero-card',
        { x: 0, opacity: 1 },
        { x: '55vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      )
      .fromTo('.hero-headline',
        { y: 0, opacity: 1 },
        { y: '-6vh', opacity: 0.35, ease: 'power2.in' },
        0.7
      )

    // What You Get section animation
    gsap.fromTo('.wyg-heading',
      { y: 24, opacity: 0 },
      {
        y: 0, opacity: 1, duration: 0.6,
        scrollTrigger: {
          trigger: whatYouGetRef.current,
          start: 'top 80%',
          end: 'top 55%',
          scrub: true
        }
      }
    )

    gsap.fromTo('.wyg-card',
      { y: 40, opacity: 0, scale: 0.98 },
      {
        y: 0, opacity: 1, scale: 1, duration: 0.5, stagger: 0.12,
        scrollTrigger: {
          trigger: '.wyg-cards',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    )

    // Stack section animation
    gsap.fromTo('.stack-heading',
      { x: '-6vw', opacity: 0 },
      {
        x: 0, opacity: 1, duration: 0.6,
        scrollTrigger: {
          trigger: stackRef.current,
          start: 'top 80%',
          end: 'top 55%',
          scrub: true
        }
      }
    )

    gsap.fromTo('.stack-card',
      { y: '10vh', opacity: 0, rotate: -1 },
      {
        y: 0, opacity: 1, rotate: 0, duration: 0.5, stagger: 0.1,
        scrollTrigger: {
          trigger: '.stack-cards',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    )

    // The Net section (pinned)
    const netScrollTl = gsap.timeline({
      scrollTrigger: {
        trigger: netRef.current,
        start: 'top top',
        end: '+=130%',
        pin: true,
        scrub: 0.6
      }
    })

    netScrollTl
      .fromTo('.net-heading',
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0
      )
      .fromTo('.net-grid',
        { x: '55vw', opacity: 0, scale: 0.985 },
        { x: 0, opacity: 1, scale: 1, ease: 'power2.out' },
        0
      )
      .fromTo('.net-cell',
        { y: '6vh', opacity: 0, scale: 0.96 },
        { y: 0, opacity: 1, scale: 1, stagger: 0.02, ease: 'power2.out' },
        0.05
      )
      .to('.net-heading',
        { x: '-30vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      )
      .to('.net-grid',
        { x: '30vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      )

    // Workflow section animation
    gsap.fromTo('.workflow-image',
      { x: '-8vw', opacity: 0, scale: 0.98 },
      {
        x: 0, opacity: 1, scale: 1, duration: 0.6,
        scrollTrigger: {
          trigger: workflowRef.current,
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    )

    gsap.fromTo('.workflow-text',
      { x: '8vw', opacity: 0 },
      {
        x: 0, opacity: 1, duration: 0.6,
        scrollTrigger: {
          trigger: workflowRef.current,
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    )

    gsap.fromTo('.workflow-item',
      { y: 16, opacity: 0 },
      {
        y: 0, opacity: 1, duration: 0.4, stagger: 0.08,
        scrollTrigger: {
          trigger: '.workflow-list',
          start: 'top 80%',
          end: 'top 55%',
          scrub: true
        }
      }
    )

    // Fresh Picks section (pinned)
    const freshScrollTl = gsap.timeline({
      scrollTrigger: {
        trigger: freshPicksRef.current,
        start: 'top top',
        end: '+=130%',
        pin: true,
        scrub: 0.6
      }
    })

    freshScrollTl
      .fromTo('.fresh-image',
        { x: '-60vw', opacity: 0, scale: 1.02 },
        { x: 0, opacity: 1, scale: 1, ease: 'power2.out' },
        0
      )
      .fromTo('.fresh-card',
        { x: '60vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0
      )
      .fromTo('.fresh-bullet',
        { x: '4vw', opacity: 0 },
        { x: 0, opacity: 1, stagger: 0.06, ease: 'power2.out' },
        0.1
      )
      .to('.fresh-image',
        { y: '-18vh', opacity: 0.25, ease: 'power2.in' },
        0.7
      )
      .to('.fresh-card',
        { y: '18vh', opacity: 0.25, ease: 'power2.in' },
        0.7
      )

    // New Arrivals section (pinned)
    const arrivalsScrollTl = gsap.timeline({
      scrollTrigger: {
        trigger: newArrivalsRef.current,
        start: 'top top',
        end: '+=130%',
        pin: true,
        scrub: 0.6
      }
    })

    arrivalsScrollTl
      .fromTo('.arrivals-text',
        { x: '-55vw', opacity: 0 },
        { x: 0, opacity: 1, ease: 'power2.out' },
        0
      )
      .fromTo('.arrival-card',
        { x: '60vw', opacity: 0, scale: 0.98 },
        { x: 0, opacity: 1, scale: 1, stagger: 0.08, ease: 'power2.out' },
        0
      )
      .to('.arrivals-text',
        { x: '-30vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      )
      .to('.arrivals-rail',
        { x: '-18vw', opacity: 0.25, ease: 'power2.in' },
        0.7
      )

    // Trending section animation
    gsap.fromTo('.trending-heading',
      { y: 20, opacity: 0 },
      {
        y: 0, opacity: 1, duration: 0.5,
        scrollTrigger: {
          trigger: trendingRef.current,
          start: 'top 80%',
          end: 'top 55%',
          scrub: true
        }
      }
    )

    gsap.fromTo('.trending-cell',
      { y: '8vh', opacity: 0, scale: 0.97 },
      {
        y: 0, opacity: 1, scale: 1, duration: 0.4, stagger: 0.06,
        scrollTrigger: {
          trigger: '.trending-grid',
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    )

    // CTA section animation
    gsap.fromTo('.cta-card',
      { y: '10vh', opacity: 0, scale: 0.98 },
      {
        y: 0, opacity: 1, scale: 1, duration: 0.6,
        scrollTrigger: {
          trigger: ctaRef.current,
          start: 'top 80%',
          end: 'top 50%',
          scrub: true
        }
      }
    )

    // Global scroll snap for pinned sections
    const pinned = ScrollTrigger.getAll().filter(st => st.vars.pin).sort((a, b) => a.start - b.start)
    const maxScroll = ScrollTrigger.maxScroll(window)
    
    if (maxScroll && pinned.length > 0) {
      const pinnedRanges = pinned.map(st => ({
        start: st.start / maxScroll,
        end: (st.end ?? st.start) / maxScroll,
        center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
      }))

      ScrollTrigger.create({
        snap: {
          snapTo: (value: number) => {
            const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02)
            if (!inPinned) return value
            
            const target = pinnedRanges.reduce((closest, r) =>
              Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
              pinnedRanges[0]?.center ?? 0
            )
            return target
          },
          duration: { min: 0.15, max: 0.35 },
          delay: 0,
          ease: 'power2.out'
        }
      })
    }

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill())
    }
  }, [])

  return (
    <div className="relative min-h-screen bg-midnight">
      {/* Noise Overlay */}
      <div className="noise-overlay" />
      
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 px-6 py-4">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-lemon" />
            <span className="font-display font-semibold text-lg text-foreground">Logic Lemon</span>
          </div>
          
          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            <a href="#newsletter" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Newsletter</a>
            <a href="#tools" className="text-sm text-muted-foreground hover:text-foreground transition-colors">Tools</a>
            <a href="#about" className="text-sm text-muted-foreground hover:text-foreground transition-colors">About</a>
            <button className="btn-lemon text-xs">Subscribe</button>
          </div>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
        
        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden absolute top-full left-0 right-0 p-4 glass-card mx-4 mt-2">
            <div className="flex flex-col gap-4">
              <a href="#newsletter" className="text-sm text-muted-foreground">Newsletter</a>
              <a href="#tools" className="text-sm text-muted-foreground">Tools</a>
              <a href="#about" className="text-sm text-muted-foreground">About</a>
              <button className="btn-lemon text-xs">Subscribe</button>
            </div>
          </div>
        )}
      </nav>

      {/* Section 1: Hero */}
      <section ref={heroRef} className="section-pinned z-10 flex items-center justify-center">
        <div className="absolute inset-0 gradient-lemon" />
        
        <div className="relative w-full h-full flex items-center justify-center px-4 sm:px-6 lg:px-8 pt-20">
          <div className="w-full max-w-7xl flex flex-col lg:flex-row items-center justify-center gap-6 lg:gap-8">
            {/* Left Image Card */}
            <div className="hero-image w-full lg:w-[42vw] h-[40vh] lg:h-[72vh] rounded-3xl overflow-hidden shadow-glass">
              <img 
                src="/images/hero_portrait.jpg" 
                alt="AI Developer" 
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Right Glass Card */}
            <div className="hero-card w-full lg:w-[40vw] min-h-[50vh] lg:h-[72vh] glass-card light-catcher p-6 lg:p-10 flex flex-col justify-center">
              <div className="flex items-center gap-2 mb-6">
                <div className="w-2 h-2 rounded-full bg-lemon" />
                <span className="font-mono text-xs uppercase tracking-widest text-muted-foreground">Logic Lemon</span>
              </div>
              
              <h1 className="hero-headline text-display font-display font-bold text-foreground mb-4">
                {'Squeeze more out of AI.'.split(' ').map((word, i) => (
                  <span key={i} className="inline-block mr-[0.25em]">{word}</span>
                ))}
              </h1>
              
              <p className="hero-subtext text-body text-muted-foreground mb-8 max-w-md">
                One newsletter. Curated tools. Practical prompts. No fluff.
              </p>
              
              <form onSubmit={handleSubmit} className="hero-form">
                <div className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="input-glass flex-1"
                    required
                  />
                  <button type="submit" className="btn-lemon whitespace-nowrap">
                    {isSubmitted ? 'Subscribed!' : 'Join the list'}
                  </button>
                </div>
                <p className="text-xs text-muted-foreground mt-3">
                  No spam. Unsubscribe anytime.
                </p>
              </form>
              
              <a href="#archive" className="inline-flex items-center gap-2 text-sm text-lemon hover:text-lemon-light transition-colors mt-6">
                Browse the archive <ArrowRight className="w-4 h-4" />
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* Section 2: What You Get */}
      <section ref={whatYouGetRef} id="newsletter" className="section-flowing z-20 bg-midnight">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="wyg-heading text-heading font-display font-bold text-foreground mb-4">
              What you get
            </h2>
            <p className="wyg-heading text-body text-muted-foreground max-w-2xl mx-auto">
              A short, weekly curation of AI tools that actually ship—plus prompts and workflows you can use immediately.
            </p>
          </div>
          
          <div className="wyg-cards grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: Sparkles, title: 'Curated tools', desc: 'We test so you don\'t waste time.' },
              { icon: Terminal, title: 'Prompts & playbooks', desc: 'Copy, tweak, run.' },
              { icon: FileText, title: 'Developer notes', desc: 'APIs, pricing, gotchas.' }
            ].map((item, i) => (
              <div key={i} className="wyg-card glass-card light-catcher p-8 glow-hover card-lift">
                <item.icon className="w-8 h-8 text-lemon mb-4" />
                <h3 className="font-display font-semibold text-xl text-foreground mb-2">{item.title}</h3>
                <p className="text-sm text-muted-foreground">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 3: The Stack */}
      <section ref={stackRef} className="section-flowing z-20 bg-midnight">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="stack-heading text-heading font-display font-bold text-foreground mb-10">
            The stack we cover
          </h2>
          
          <div className="stack-cards grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { 
                image: '/images/trending_1.jpg', 
                title: 'Generative UX', 
                desc: 'UI generation, design systems, accessibility.' 
              },
              { 
                image: '/images/trending_2.jpg', 
                title: 'Code Assistants', 
                desc: 'Autocomplete, review, refactoring, tests.' 
              },
              { 
                image: '/images/trending_3.jpg', 
                title: 'Data & Ops', 
                desc: 'Query builders, runbooks, monitoring.' 
              }
            ].map((item, i) => (
              <div key={i} className="stack-card glass-card light-catcher overflow-hidden glow-hover card-lift">
                <div className="h-48 overflow-hidden">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-6">
                  <h3 className="font-display font-semibold text-lg text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 4: The Net - Bento Grid */}
      <section ref={netRef} id="tools" className="section-pinned z-30 bg-midnight">
        <div className="absolute inset-0 gradient-lemon-bottom" />
        
        <div className="relative w-full h-full flex flex-col lg:flex-row items-center justify-center px-4 sm:px-6 lg:px-8 pt-20">
          {/* Left Heading */}
          <div className="net-heading w-full lg:w-[34vw] mb-8 lg:mb-0 lg:pr-8">
            <h2 className="text-display font-display font-bold text-foreground mb-4">
              The Net
            </h2>
            <p className="text-body text-muted-foreground mb-6">
              A living map of the AI tools we review, compare, and integrate.
            </p>
            <button className="btn-secondary text-sm">
              Request a tool <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </div>
          
          {/* Right Bento Grid */}
          <div className="net-grid w-full lg:w-[50vw] h-auto lg:h-[76vh]">
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3 lg:gap-4 h-full">
              {[
                { icon: Code, label: 'Code Assistants', size: 'normal' },
                { icon: Palette, label: 'UI Generators', size: 'normal' },
                { icon: Layers, label: 'Prompt Libraries', size: 'normal' },
                { icon: Cpu, label: 'Model APIs', size: 'normal', image: '/images/net_cell_1.jpg' },
                { icon: Shield, label: 'Security', size: 'normal' },
                { icon: Check, label: 'Testing', size: 'normal' },
                { icon: FileText, label: 'Docs', size: 'normal' },
                { icon: Database, label: 'Data', size: 'normal' },
                { icon: Box, label: 'Integrations', size: 'normal' }
              ].map((cell, i) => (
                <div 
                  key={i} 
                  className={`net-cell glass-card light-catcher glow-hover flex flex-col items-center justify-center p-4 lg:p-6 ${
                    cell.image ? 'relative overflow-hidden' : ''
                  }`}
                >
                  {cell.image && (
                    <img src={cell.image} alt="" className="absolute inset-0 w-full h-full object-cover opacity-40" />
                  )}
                  <div className={`relative z-10 flex flex-col items-center ${cell.image ? 'text-white' : ''}`}>
                    <cell.icon className={`w-6 h-6 lg:w-8 lg:h-8 ${cell.image ? 'text-white' : 'text-lemon'} mb-2`} />
                    <span className={`text-xs lg:text-sm font-medium text-center ${cell.image ? 'text-white' : 'text-foreground'}`}>
                      {cell.label}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 5: Workflow Tips */}
      <section ref={workflowRef} className="section-flowing z-20 bg-midnight">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col lg:flex-row items-center gap-8 lg:gap-12">
            {/* Left Image */}
            <div className="workflow-image w-full lg:w-[44vw] h-[40vh] lg:h-[56vh] glass-card light-catcher overflow-hidden">
              <img 
                src="/images/new_arrival_3.jpg" 
                alt="Workflow" 
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Right Text */}
            <div className="workflow-text w-full lg:w-[40vw]">
              <h2 className="text-heading font-display font-bold text-foreground mb-4">
                Workflow tips
              </h2>
              <p className="text-body text-muted-foreground mb-8">
                Start with the job-to-be-done. Pick one tool. Build a 3-step habit. Then layer in automation.
              </p>
              
              <div className="workflow-list space-y-6">
                {[
                  { num: '01', title: 'Define the output', desc: 'What finished looks like.' },
                  { num: '02', title: 'Choose the interface', desc: 'Chat vs API vs embedded.' },
                  { num: '03', title: 'Measure the delta', desc: 'Time saved vs old workflow.' }
                ].map((item, i) => (
                  <div key={i} className="workflow-item flex gap-4">
                    <span className="font-mono text-sm text-lemon font-medium">{item.num}</span>
                    <div>
                      <h4 className="font-display font-semibold text-foreground mb-1">{item.title}</h4>
                      <p className="text-sm text-muted-foreground">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Section 6: Fresh Picks */}
      <section ref={freshPicksRef} className="section-pinned z-30 bg-midnight">
        <div className="relative w-full h-full flex flex-col lg:flex-row items-center justify-center px-4 sm:px-6 lg:px-8 pt-20">
          {/* Left Image */}
          <div className="fresh-image w-full lg:w-[46vw] h-[40vh] lg:h-[76vh] rounded-3xl overflow-hidden shadow-glass mb-6 lg:mb-0">
            <img 
              src="/images/fresh_picks_feature.jpg" 
              alt="Fresh Picks" 
              className="w-full h-full object-cover"
            />
          </div>
          
          {/* Right Glass Card */}
          <div className="fresh-card w-full lg:w-[40vw] min-h-[50vh] lg:h-[76vh] glass-card light-catcher p-6 lg:p-10 flex flex-col justify-center">
            <span className="label-mono text-lemon mb-4">Fresh picks</span>
            
            <h2 className="text-heading font-display font-bold text-foreground mb-6">
              The best AI releases this month.
            </h2>
            
            <div className="space-y-4 mb-8">
              {[
                'New coding agents with multi-file context',
                'Design-to-code tools that respect spacing',
                'Safer prompt patterns for production'
              ].map((item, i) => (
                <div key={i} className="fresh-bullet flex items-start gap-3">
                  <Check className="w-5 h-5 text-lemon flex-shrink-0 mt-0.5" />
                  <span className="text-sm text-foreground">{item}</span>
                </div>
              ))}
            </div>
            
            <div className="flex flex-col sm:flex-row gap-3">
              <button className="btn-lemon">
                Read the roundup
              </button>
              <button className="btn-secondary">
                See the shortlist
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Section 7: New Arrivals */}
      <section ref={newArrivalsRef} className="section-pinned z-30 bg-midnight">
        <div className="absolute inset-0 gradient-lemon" />
        
        <div className="relative w-full h-full flex flex-col lg:flex-row items-center justify-center px-4 sm:px-6 lg:px-8 pt-20">
          {/* Left Text Card */}
          <div className="arrivals-text w-full lg:w-[34vw] mb-8 lg:mb-0 lg:pr-8">
            <h2 className="text-heading font-display font-bold text-foreground mb-4">
              New arrivals
            </h2>
            <p className="text-body text-muted-foreground mb-6">
              Tools we're benchmarking right now—summaries, pricing, and first impressions.
            </p>
            <button className="btn-secondary text-sm">
              View all new <ArrowRight className="w-4 h-4 ml-2" />
            </button>
          </div>
          
          {/* Right Rail */}
          <div className="arrivals-rail w-full lg:w-[52vw] overflow-x-auto hide-scrollbar">
            <div className="flex gap-4 lg:gap-6 pb-4">
              {[
                { image: '/images/new_arrival_1.jpg', title: 'Agentic IDE', tag: 'Code' },
                { image: '/images/new_arrival_2.jpg', title: 'Design-to-Code', tag: 'Design' },
                { image: '/images/new_arrival_3.jpg', title: 'Prompt Test Runner', tag: 'Testing' }
              ].map((card, i) => (
                <div 
                  key={i} 
                  className="arrival-card flex-shrink-0 w-[280px] lg:w-[38vw] h-[50vh] lg:h-[76vh] glass-card light-catcher overflow-hidden glow-hover"
                >
                  <div className="h-[60%] overflow-hidden">
                    <img src={card.image} alt={card.title} className="w-full h-full object-cover" />
                  </div>
                  <div className="p-6">
                    <span className="label-mono text-lemon text-[10px]">{card.tag}</span>
                    <h3 className="font-display font-semibold text-lg text-foreground mt-2">{card.title}</h3>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Section 8: Trending */}
      <section ref={trendingRef} className="section-flowing z-20 bg-midnight">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-10">
            <h2 className="trending-heading text-heading font-display font-bold text-foreground mb-4">
              Trending
            </h2>
            <p className="text-body text-muted-foreground max-w-2xl">
              The most-clicked tools this week—based on what the community is actually trying.
            </p>
          </div>
          
          <div className="trending-grid grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { image: '/images/trending_1.jpg', title: 'Code Review Agent', desc: 'AI-powered code review' },
              { image: '/images/trending_2.jpg', title: 'UI Generator', desc: 'Generate UI from prompts' },
              { image: '/images/trending_3.jpg', title: 'Test Writer', desc: 'Automated test generation' },
              { image: '/images/trending_4.jpg', title: 'Docs Assistant', desc: 'AI documentation helper' },
              { image: '/images/trending_5.jpg', title: 'Query Builder', desc: 'Natural language to SQL' },
              { image: '/images/trending_6.jpg', title: 'Security Scanner', desc: 'AI vulnerability detection' }
            ].map((item, i) => (
              <div key={i} className="trending-cell glass-card light-catcher overflow-hidden glow-hover card-lift">
                <div className="h-40 overflow-hidden">
                  <img src={item.image} alt={item.title} className="w-full h-full object-cover" />
                </div>
                <div className="p-5">
                  <h3 className="font-display font-semibold text-foreground mb-1">{item.title}</h3>
                  <p className="text-xs text-muted-foreground">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Section 9: CTA + Footer */}
      <section ref={ctaRef} id="about" className="section-flowing z-20 bg-midnight pb-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="cta-card glass-card light-catcher p-8 lg:p-16 text-center">
            <h2 className="text-heading font-display font-bold text-foreground mb-4">
              Get the next issue.
            </h2>
            <p className="text-body text-muted-foreground mb-8 max-w-md mx-auto">
              Weekly tools, prompts, and workflows—delivered every Tuesday.
            </p>
            
            <form onSubmit={handleSubmit} className="max-w-md mx-auto mb-12">
              <div className="flex flex-col sm:flex-row gap-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  className="input-glass flex-1"
                  required
                />
                <button type="submit" className="btn-lemon whitespace-nowrap">
                  {isSubmitted ? 'Subscribed!' : 'Subscribe'}
                </button>
              </div>
            </form>
            
            {/* Footer Links */}
            <div className="flex flex-wrap justify-center gap-6 mb-8">
              {['About', 'Advertise', 'Privacy', 'Terms', 'Contact'].map((link) => (
                <a 
                  key={link} 
                  href={`#${link.toLowerCase()}`} 
                  className="text-sm text-muted-foreground hover:text-foreground transition-colors"
                >
                  {link}
                </a>
              ))}
            </div>
            
            <p className="text-xs text-muted-foreground">
              © Logic Lemon AI. All rights reserved.
            </p>
          </div>
        </div>
      </section>

      {/* Sticky CTA for Mobile */}
      <div className="sticky-cta">
        <button className="btn-lemon w-full">
          Subscribe to Newsletter
        </button>
      </div>
    </div>
  )
}

export default App
